/* 
 * File:   graham.h
 * Author: Francisco Rosa Dias de Miranda e Hiago Vinicius Americo
 
 */

#ifndef GRAHAM_H
#define GRAHAM_H

#include "pilha.h"
#include "lista.h"


LISTA * graham (LISTA * L);

#endif